package com.sp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.sp.model.Employee;

@Repository
public class EmployeeService {
     final String url="http://localhost:5555/api/employee";
     
     @Autowired
 	private RestTemplate template;
 	HttpHeaders header=new HttpHeaders();
 	
	public int insert(Employee employee) {
	     
		employee=template.postForObject(url, employee, Employee.class);
		
		if(employee!=null)
		return 1;
		else return 0;
		
	}

}
