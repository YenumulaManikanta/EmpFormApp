package com.sp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.sp.model.Employee;
import com.sp.service.EmployeeService;



@Controller
public class EmployeeController {
	
	@Autowired
	private EmployeeService service;
	

	  @RequestMapping("/empRegister")
		public ModelAndView showForm() {
			return new ModelAndView("empRegister","command",new Employee());
		}

	
    @PostMapping("/empform")
    public ModelAndView add( @RequestBody Employee employee) {
    int result= service.insert(employee);
   
     if(result==1) {
    	return new ModelAndView( "success","message","record enter successfully");
     }
     else {
    	 return new ModelAndView( "success","message","record not enter");
     }
     
    }
	
}
